﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System;

namespace EnumAsDiscriminatorBug.Data
{
    public class DataContextFactory : IDesignTimeDbContextFactory<DataContext>
    {
        public DataContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<DataContext>();
            var connectionString = Environment.GetEnvironmentVariable("strr");
            optionsBuilder.UseNpgsql(connectionString ?? "string", o => o.SetPostgresVersion(9, 6)).UseLazyLoadingProxies();

            return new DataContext(optionsBuilder.Options);
        }
    }
}