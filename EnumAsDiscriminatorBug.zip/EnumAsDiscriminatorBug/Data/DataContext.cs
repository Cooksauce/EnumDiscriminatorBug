﻿using EnumAsDiscriminatorBug.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace EnumAsDiscriminatorBug.Data
{
    public class DataContext : DbContext
    {
        public DataContext() : base()
        {
        }

        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new ALeft.Config());
            modelBuilder.ApplyConfiguration(new Base.Config());

            //modelBuilder.ApplyConfigurationsFromAssembly(typeof(DataContext).Assembly);
        }
    }
}