﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnumAsDiscriminatorBug.Data.Entities
{
    public abstract class Base
    {
        public int Id { get; set; }

        public Direction Discriminator { get; set; }

        public class Config : IEntityTypeConfiguration<Base>
        {
            public void Configure(EntityTypeBuilder<Base> builder)
            {
                builder.HasDiscriminator(o => o.Discriminator)
                       .HasValue<ALeft>(Direction.Left);
                       //.HasValue<Right>(Direction.Right);
            }
        }
    }

    public class ALeft : Base
    {
        public new class Config : IEntityTypeConfiguration<ALeft>
        {
            public void Configure(EntityTypeBuilder<ALeft> builder)
            {
            }
        }
    }


    //public class Right : Base { }

    public enum Direction
    {
        Left,
        Right
    }
}